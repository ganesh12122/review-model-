import { Component, OnInit } from '@angular/core';
import { Review } from '../../../models/review.model';
import { ReviewService } from '../../../services/review.service';

@Component({
  selector: 'app-review-list',
  templateUrl: './review-list.component.html',
  styleUrls: ['./review-list.component.css']
})
export class ReviewListComponent implements OnInit {
  reviews: Review[] = [];
  selectedRating: number | null = null;
  errorMessage: string = '';

  constructor(private reviewService: ReviewService) { }

  ngOnInit(): void {
    this.loadReviews();
  }

  loadReviews(): void {
    if (this.selectedRating) {
      this.reviewService.getReviewsByRating(this.selectedRating).subscribe({
        next: (data) => this.reviews = data,
        error: (error) => this.errorMessage = 'Error loading reviews'
      });
    } else {
      this.reviewService.getAllReviews().subscribe({
        next: (data) => this.reviews = data,
        error: (error) => this.errorMessage = 'Error loading reviews'
      });
    }
  }

  filterByRating(rating: number): void {
    this.selectedRating = rating;
    this.loadReviews();
  }

  deleteReview(id: number): void {
    if (confirm('Are you sure you want to delete this review?')) {
      this.reviewService.deleteReview(id).subscribe({
        next: () => {
          this.reviews = this.reviews.filter(review => review.id !== id);
        },
        error: (error) => this.errorMessage = 'Error deleting review'
      });
    }
  }
}