import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ReviewService } from '../../../services/review.service';
import { Review } from '../../../models/review.model';

@Component({
  selector: 'app-review-form',
  templateUrl: './review-form.component.html',
  styleUrls: ['./review-form.component.css']
})
export class ReviewFormComponent implements OnInit {
  reviewForm: FormGroup;
  isEditMode: boolean = false;
  reviewId: number | null = null;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private reviewService: ReviewService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.reviewForm = this.fb.group({
      rating: ['', [Validators.required, Validators.min(1), Validators.max(5)]],
      comment: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.reviewId = +id;
      this.loadReview(this.reviewId);
    }
  }

  loadReview(id: number): void {
    this.reviewService.getReviewById(id).subscribe({
      next: (review) => {
        this.reviewForm.patchValue({
          rating: review.rating,
          comment: review.comment
        });
      },
      error: (error) => this.errorMessage = 'Error loading review'
    });
  }

  onSubmit(): void {
    if (this.reviewForm.valid) {
      const review: Review = {
        ...this.reviewForm.value,
        reviewDate: new Date()
      };

      if (this.isEditMode && this.reviewId) {
        this.reviewService.updateReview(this.reviewId, review).subscribe({
          next: () => this.router.navigate(['/reviews']),
          error: (error) => this.errorMessage = 'Error updating review'
        });
      } else {
        this.reviewService.createReview(review).subscribe({
          next: () => this.router.navigate(['/reviews']),
          error: (error) => this.errorMessage = 'Error creating review'
        });
      }
    }
  }
}