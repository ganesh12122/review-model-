import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReviewListComponent } from './components/review/review-list/review-list.component';
import { ReviewFormComponent } from './components/review/review-form/review-form.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ReviewListComponent, ReviewFormComponent, CommonModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <div class="container">
        <a class="navbar-brand" routerLink="/">Hotel Management System</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" routerLink="/reviews" routerLinkActive="active">Reviews</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" routerLink="/reviews/new" routerLinkActive="active">Add Review</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'Hotel Management System';
}