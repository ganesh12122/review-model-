import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Review } from '../models/review.model';

@Injectable({
  providedIn: 'root'
})
export class ReviewService {
  private apiUrl = 'http://localhost:8080/api/review';

  // Mock data for testing UI
  private mockReviews: Review[] = [
    {
      id: 1,
      rating: 5,
      comment: "Excellent stay! The room was spotless and the staff was incredibly friendly. The breakfast buffet was outstanding.",
      reviewDate: new Date('2024-01-15')
    },
    {
      id: 2,
      rating: 4,
      comment: "Very good experience overall. Comfortable beds and great location. Only minor issue was the slow WiFi.",
      reviewDate: new Date('2024-01-10')
    },
    {
      id: 3,
      rating: 3,
      comment: "Average stay. Room was okay but could use some updating. Staff was helpful though.",
      reviewDate: new Date('2024-01-05')
    },
    {
      id: 4,
      rating: 5,
      comment: "Perfect weekend getaway! The spa services were amazing and the room had a beautiful view.",
      reviewDate: new Date('2024-01-01')
    }
  ];

  constructor(private http: HttpClient) { }

  getAllReviews(): Observable<Review[]> {
    return of(this.mockReviews);
  }

  getReviewById(id: number): Observable<Review> {
    const review = this.mockReviews.find(r => r.id === id);
    return of(review!);
  }

  getReviewsByRating(rating: number): Observable<Review[]> {
    const filteredReviews = this.mockReviews.filter(r => r.rating === rating);
    return of(filteredReviews);
  }

  createReview(review: Review): Observable<Review> {
    const newReview = {
      ...review,
      id: this.mockReviews.length + 1,
      reviewDate: new Date()
    };
    this.mockReviews.push(newReview);
    return of(newReview);
  }

  updateReview(id: number, review: Review): Observable<Review> {
    const index = this.mockReviews.findIndex(r => r.id === id);
    if (index !== -1) {
      this.mockReviews[index] = { ...review, id };
      return of(this.mockReviews[index]);
    }
    return of(review);
  }

  deleteReview(id: number): Observable<void> {
    const index = this.mockReviews.findIndex(r => r.id === id);
    if (index !== -1) {
      this.mockReviews.splice(index, 1);
    }
    return of(void 0);
  }
}