import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ReviewService } from '../../../services/review.service';

@Component({
  selector: 'app-review-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  template: `
    <div class="container mt-4">
      <h2>{{isEditMode ? 'Edit' : 'Create'}} Review</h2>

      <form [formGroup]="reviewForm" (ngSubmit)="onSubmit()" class="mt-4">
        <!-- Error Message -->
        <div *ngIf="errorMessage" class="alert alert-danger">
          {{errorMessage}}
        </div>

        <!-- Rating Field -->
        <div class="mb-3">
          <label for="rating" class="form-label">Rating</label>
          <select id="rating" formControlName="rating" class="form-select">
            <option value="">Select Rating</option>
            <option *ngFor="let rating of [1,2,3,4,5]" [value]="rating">
              {{rating}} ★
            </option>
          </select>
          <div *ngIf="reviewForm.get('rating')?.invalid && reviewForm.get('rating')?.touched" 
               class="text-danger">
            Please select a rating
          </div>
        </div>

        <!-- Comment Field -->
        <div class="mb-3">
          <label for="comment" class="form-label">Comment</label>
          <textarea id="comment" 
                    formControlName="comment" 
                    class="form-control" 
                    rows="4">
          </textarea>
          <div *ngIf="reviewForm.get('comment')?.invalid && reviewForm.get('comment')?.touched" 
               class="text-danger">
            Comment must be at least 10 characters long
          </div>
        </div>

        <!-- Submit Button -->
        <div class="d-flex gap-2">
          <button type="submit" 
                  [disabled]="reviewForm.invalid" 
                  class="btn btn-primary">
            {{isEditMode ? 'Update' : 'Submit'}} Review
          </button>
          <button type="button" 
                  routerLink="/reviews" 
                  class="btn btn-secondary">
            Cancel
          </button>
        </div>
      </form>
    </div>
  `
})
export class ReviewFormComponent implements OnInit {
  reviewForm: FormGroup;
  isEditMode: boolean = false;
  reviewId: number | null = null;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private reviewService: ReviewService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.reviewForm = this.fb.group({
      rating: ['', [Validators.required]],
      comment: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEditMode = true;
      this.reviewId = +id;
      this.loadReview(this.reviewId);
    }
  }

  loadReview(id: number): void {
    this.reviewService.getReviewById(id).subscribe({
      next: (review) => {
        this.reviewForm.patchValue({
          rating: review.rating,
          comment: review.comment
        });
      },
      error: () => this.errorMessage = 'Error loading review'
    });
  }

  onSubmit(): void {
    if (this.reviewForm.valid) {
      const review = {
        ...this.reviewForm.value,
        reviewDate: new Date()
      };

      if (this.isEditMode && this.reviewId) {
        this.reviewService.updateReview(this.reviewId, review).subscribe({
          next: () => this.router.navigate(['/reviews']),
          error: () => this.errorMessage = 'Error updating review'
        });
      } else {
        this.reviewService.createReview(review).subscribe({
          next: () => this.router.navigate(['/reviews']),
          error: () => this.errorMessage = 'Error creating review'
        });
      }
    }
  }
}