import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Review } from '../../../models/review.model';
import { ReviewService } from '../../../services/review.service';

@Component({
  selector: 'app-review-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="container mt-4">
      <h2>Hotel Reviews</h2>
      
      <!-- Filter Section -->
      <div class="mb-4">
        <label class="me-2">Filter by Rating:</label>
        <div class="btn-group" role="group">
          <button *ngFor="let rating of [1,2,3,4,5]"
                  (click)="filterByRating(rating)"
                  [class.active]="selectedRating === rating"
                  class="btn btn-outline-primary">
            {{rating}} ★
          </button>
          <button (click)="clearFilter()"
                  class="btn btn-outline-secondary">
            Clear Filter
          </button>
        </div>
      </div>

      <!-- Error Message -->
      <div *ngIf="errorMessage" class="alert alert-danger">
        {{errorMessage}}
      </div>

      <!-- Reviews List -->
      <div class="row">
        <div *ngFor="let review of reviews" class="col-md-6 mb-3">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between">
                <h5 class="card-title">Rating: {{review.rating}} ★</h5>
                <small class="text-muted">{{review.reviewDate | date}}</small>
              </div>
              <p class="card-text">{{review.comment}}</p>
              <div class="btn-group">
                <button [routerLink]="['/reviews/edit', review.id]" 
                        class="btn btn-sm btn-outline-primary">
                  Edit
                </button>
                <button (click)="deleteReview(review.id!)" 
                        class="btn btn-sm btn-outline-danger">
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ReviewListComponent implements OnInit {
  reviews: Review[] = [];
  selectedRating: number | null = null;
  errorMessage: string = '';

  constructor(private reviewService: ReviewService) { }

  ngOnInit(): void {
    this.loadReviews();
  }

  loadReviews(): void {
    if (this.selectedRating) {
      this.reviewService.getReviewsByRating(this.selectedRating).subscribe({
        next: (data) => this.reviews = data,
        error: () => this.errorMessage = 'Error loading reviews'
      });
    } else {
      this.reviewService.getAllReviews().subscribe({
        next: (data) => this.reviews = data,
        error: () => this.errorMessage = 'Error loading reviews'
      });
    }
  }

  filterByRating(rating: number): void {
    this.selectedRating = rating;
    this.loadReviews();
  }

  clearFilter(): void {
    this.selectedRating = null;
    this.loadReviews();
  }

  deleteReview(id: number): void {
    if (confirm('Are you sure you want to delete this review?')) {
      this.reviewService.deleteReview(id).subscribe({
        next: () => {
          this.reviews = this.reviews.filter(review => review.id !== id);
        },
        error: () => this.errorMessage = 'Error deleting review'
      });
    }
  }
}